// Product data
export const products = [
  // Cookies
  {
    id: 'cookie-1',
    name: 'Chocolate Chip Cookies',
    description: 'Classic cookies with premium chocolate chips and a soft, chewy center
